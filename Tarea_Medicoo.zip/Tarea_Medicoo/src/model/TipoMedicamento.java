package model;

public enum TipoMedicamento {
	Antiinflamatorio, Fiebre, Tos, Vomitos;

}
