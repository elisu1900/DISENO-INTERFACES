package main;


import view.MainView;

public class MainApp {

	public static void main(String[] args) {

		MainView ventana = new MainView();
		ventana.setVisible(true);
	}

}
